# DAY6

//https://chatgpt.com/share/686df3ce-43b8-8002-a154-5d794eed5559

fn->which user can access which url and which method

